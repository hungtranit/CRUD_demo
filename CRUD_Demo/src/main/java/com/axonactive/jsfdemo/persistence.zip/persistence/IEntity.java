package com.axonactive.jsfdemo.persistence;

public interface IEntity {

	int getId();
}
